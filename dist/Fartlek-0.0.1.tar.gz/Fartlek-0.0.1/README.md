# Classifer from Imbalanced Data


Uses Gaussian Normal distribution for data generation. Based upon the requirement samples are extracted from the distribution. It gives ouput in form isotrophic gaussian blobs.